import styles from '../components/Index.css'

export default function Index({ Component, pageProps}){
    return (
        <>
            <Component {...pageProps} />
        </>

    )
}