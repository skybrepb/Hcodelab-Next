'use strict'

class ContactController {
}

module.exports = ContactController
